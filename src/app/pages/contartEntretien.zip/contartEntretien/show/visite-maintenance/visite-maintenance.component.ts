import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { ContratEntretien } from 'app/Models/Entities/ContratEntretien';
import { TranslateService } from '@ngx-translate/core';
import { AppSettings } from 'app/app-settings/app-settings';
import { VisiteMaintenance, VisiteMaintenanceViewModel } from 'app/Models/Entities/VisiteMaintenance';
//mport { groupBy } from 'lodash-es'
import * as _ from 'lodash';
import { sortBy } from 'lodash';
import { StatutVisiteMaintenance } from 'app/Enums/StatutVisiteMaintenance';
import { moisEnum } from 'app/common/gamme-maintenance-equipement/sheard/enums/mois.enum';
import { MenuItem } from 'app/custom-module/primeng/api';
import { VisiteMaintenanceService } from 'app/services/visisteMaintenance/visite-maintenance.service';

declare var jQuery: any;
declare var swal: any;
@Component({
  selector: 'app-visite-maintenance',
  templateUrl: './visite-maintenance.component.html',
  styleUrls: ['./visite-maintenance.component.scss']
})
export class VisiteMaintenanceComponent implements OnInit, OnChanges {
  @Output('OnRefresh') refresh = new EventEmitter();
  @Input("contratEntretien") contratEntretien: ContratEntretien

  visitesMaintenances: VisiteMaintenanceViewModel[] = [];
  statutVisiteMaintenance: typeof StatutVisiteMaintenance = StatutVisiteMaintenance;
  moisEnum: typeof moisEnum = moisEnum;
  labels: any = null;
  actionsItems: MenuItem[] = [];
  constructor(private translate: TranslateService,
    private visiteMaintenanceService: VisiteMaintenanceService) { }

  ngOnInit() {
    this.translate.setDefaultLang(AppSettings.lang);
    this.translate.use(AppSettings.lang);
    this.translate.get("labels").subscribe(text => {
      this.labels = text;
    });
  }
  ngOnChanges() {
    //this.gamme_maintenance_equipement_Selected = this.formatGamme_maintenance_equipement_Selected(this.contratEntretien.equipementContrat);
    const visiteMaintenance = this.contratEntretien.visiteMaintenance;
    console.log("visiteMaintenance", visiteMaintenance)
    // const cc = sortBy(visiteMaintenance, ['mois'])
    const states: VisiteMaintenanceViewModel = _.groupBy(visiteMaintenance, 'annee')
    this.visitesMaintenances = [];
    console.log("states", states)
    for (let key in states) {
      this.visitesMaintenances.push({
        year: parseInt(key),
        visitesMaintenances: states[key]
      });
    }
  }


  getConditionActions(typeAction, visitesMaintenances: VisiteMaintenance[], mois: number) {
    debugger
    console.log("bbb", visitesMaintenances)
    if (visitesMaintenances == undefined) {
      return true;
    } else {
      var list = visitesMaintenances.filter(x => x.mois == mois);
    }
    const visiteMaintenance = list.length == 0 ? null : list[0];

    switch (typeAction) {
      case 'planifier':
        return (visiteMaintenance.statut == this.statutVisiteMaintenance.APlanifier) ? true : false;
      case 'annelee':
        return (visiteMaintenance.statut == this.statutVisiteMaintenance.Planifier  /* &&ficheintervention ==null */ || visiteMaintenance.statut == this.statutVisiteMaintenance.APlanifier) ? true : false;
      case 'aplanifier':
        return (visiteMaintenance.statut == this.statutVisiteMaintenance.Planifier /* &&ficheintervention ==null */ || visiteMaintenance.statut == this.statutVisiteMaintenance.Annule) ? true : false;
      case 'ficheintervention':
        return (visiteMaintenance.statut == this.statutVisiteMaintenance.Planifier /* &&ficheintervention ==null */) ? true : false;

    }
  }
  changeStatutVisiteMaintenance(statut: StatutVisiteMaintenance, visitesMaintenances: VisiteMaintenance[], mois: number) {
    if (visitesMaintenances == undefined) {
      return true;
    } else {
      var list = visitesMaintenances.filter(x => x.mois == mois);
    }
    const visiteMaintenance = list.length == 0 ? null : list[0];
    this.translate.get(this.getTransalteLocationRequest(statut)).subscribe(text => {
      swal({
        title: text.title,
        text: text.question,
        icon: "warning",
        buttons: {
          cancel: {
            text: text.cancel,
            value: null,
            visible: true,
            className: "",
            closeModal: false
          },
          confirm: {
            text: text.confirm,
            value: true,
            visible: true,
            className: "",
            closeModal: false
          }
        }
      }).then(isConfirm => {
        if (isConfirm) {

          this.visiteMaintenanceService.changeStatut({ idVisiteMaintenance: visiteMaintenance.id, statutVisiteMaintenance: statut }).subscribe(res => {
            if (res) {
              swal(text.success, "", "success");
              this.refresh.emit('1');
            } else {
              swal(text.ImpossibleDeSuppression, "", "error");
            }
          });
        } else {
          swal(text.cancel, "", "error");
        }
      });
    });
  }
  /**
   * @summary fonction générique s'utiliser dans la fonction du changement du statut d'un visite maintenance 
   * @todo déterminer la requête pour récupérer la traduction à partirdu ficher json de traduction
   * @param statut le statut du chantier qui nous voulons récupérer leur traduction
   */
  getTransalteLocationRequest(statut: StatutVisiteMaintenance): string {
    debugger
    (statut)

    let StatusLabel: string = this.statutVisiteMaintenance[statut].toLowerCase();
    (StatusLabel)
    console.log(StatusLabel)
    return `changeStatutVisiteMaintenance.${StatusLabel}`;
  }

  createFicheIntervention(visitesMaintenances: VisiteMaintenance) {
    console.log("ficheintervention", visitesMaintenances)
  }


  getStatutByMonth(visitesMaintenances: VisiteMaintenance[], mois: number) {
    const list = visitesMaintenances.filter(x => x.mois == mois);
    if (list.length == 0) {
      return null;
    } else {
      return this.getLabelleByStatut(list[0].statut);
    }

  }

  getLabelleByStatut(statut: StatutVisiteMaintenance) {

    if (this.labels == null) {
      return
    }
    switch (statut) {
      case this.statutVisiteMaintenance.APlanifier:
        return this.labels.aplanifier;
        break;
      case this.statutVisiteMaintenance.Planifier:
        return this.labels.planifier;
        break;
      case this.statutVisiteMaintenance.Annule:
        return this.labels.annulee;
        break;
      case this.statutVisiteMaintenance.Fait:
        return this.labels.fait;
        break;
      case this.statutVisiteMaintenance.NonFait:
        return this.labels.nonfait;
        break;
      // 
    }
  }

}
