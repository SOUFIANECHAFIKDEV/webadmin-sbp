import { ContratEntretien } from "app/Models/Entities/ContratEntretien";

export class ContratEntretienState {
  static contratEntretien: ContratEntretien = new ContratEntretien();
}